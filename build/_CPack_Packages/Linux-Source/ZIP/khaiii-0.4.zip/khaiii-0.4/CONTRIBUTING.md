## Submitting Pull Requests

When you are sending a pull request, please sign the [CLA](https://cla-assistant.io/kakao/khaiii)(Contributor Licensing Agreement) for Individual.  
If you need a Contributor Licensing Agreement for Corporate, please [contact us](mailto:oss@kakaocorp.com).
